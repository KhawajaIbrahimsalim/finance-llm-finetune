import os
import torch
from pathlib import Path
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE_MODEL = os.getenv("BASE_MODEL", r"Qwen/Qwen2.5-0.5B")
LORA_PATH = os.getenv("LORA_PATH", r"experiments/run_1")
PROJECT_ROOT = Path(__file__).resolve().parents[2]
HAS_CUDA = torch.cuda.is_available()
DTYPE = torch.bfloat16 if HAS_CUDA and torch.cuda.is_bf16_supported() else torch.float16


def find_adapter_dir(path):
    adapter_config = "adapter_config.json"

    if (path / adapter_config).is_file():
        return path

    checkpoint_dirs = sorted(
        path.glob("checkpoint-*"),
        key=lambda p: int(p.name.rsplit("-", 1)[-1]) if p.name.rsplit("-", 1)[-1].isdigit() else -1,
        reverse=True,
    )
    for checkpoint_dir in checkpoint_dirs:
        if (checkpoint_dir / adapter_config).is_file():
            return checkpoint_dir

    nested_adapters = sorted(
        path.rglob(adapter_config),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if nested_adapters:
        return nested_adapters[0].parent

    return None


def resolve_adapter_path(path):
    path = Path(path).expanduser()
    candidates = []

    if path.is_absolute():
        candidates.append(path)
    else:
        candidates.extend([Path.cwd() / path, PROJECT_ROOT / path])

    for kaggle_root in [Path("/kaggle/working"), Path("/kaggle/input")]:
        candidates.append(kaggle_root / path)

    seen = set()
    searched = []
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen or not candidate.exists():
            continue
        seen.add(candidate)
        searched.append(str(candidate))
        adapter_dir = find_adapter_dir(candidate)
        if adapter_dir is not None:
            print(f"Using LoRA adapter from: {adapter_dir}")
            return adapter_dir

    for search_root in [PROJECT_ROOT, Path.cwd(), Path("/kaggle/working"), Path("/kaggle/input")]:
        if not search_root.exists():
            continue
        searched.append(str(search_root))
        matches = sorted(
            search_root.rglob("adapter_config.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if matches:
            adapter_dir = matches[0].parent
            print(f"Using LoRA adapter found at: {adapter_dir}")
            return adapter_dir

    raise FileNotFoundError(
        "Could not find adapter_config.json. "
        "Run training first with `python main.py`, or set LORA_PATH to the folder that "
        "contains your saved LoRA adapter. That folder must contain adapter_config.json. "
        "If you loaded a Kaggle Dataset containing the trained adapter, set LORA_PATH to "
        "its path under /kaggle/input.\n"
        f"Searched: {searched}"
    )


print("Loading base model...")

base_model = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    torch_dtype=DTYPE if HAS_CUDA else torch.float32,
    device_map="auto" if HAS_CUDA else "cpu",
)

tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)
tokenizer.pad_token = tokenizer.eos_token

print("Loading LoRA adapter...")

adapter_path = resolve_adapter_path(LORA_PATH)
model = PeftModel.from_pretrained(base_model, adapter_path)

model.eval()
device = next(model.parameters()).device

print("Ready!\n")

while True:
    prompt = input("You: ")

    if prompt.lower() == "exit":
        break

    inputs = tokenizer(prompt, return_tensors="pt").to(device)

    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=150,
            temperature=0.7,
            do_sample=True
        )

    print(tokenizer.decode(output[0], skip_special_tokens=True))
